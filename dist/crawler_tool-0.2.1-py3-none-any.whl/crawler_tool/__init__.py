# -*- coding: utf-8 -*-

__version__ = "0.1"

# 布隆过滤器
from crawler_tool.bloomfilter import BloomFilter
# 获取User-Agent
from crawler_tool.fack_header import UserAgent
